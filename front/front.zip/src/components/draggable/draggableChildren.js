import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';

const DraggableChildren = (props)=>{
    const setElement = (ele)=>{
        if(!window.draggables)
            window.draggables = {}
        window.draggables[props.id] = ele
    }
    const getElement = ()=>{
        return window.draggables[props.id];
    }
    useEffect(()=>{
        if(!props.id)
            console.error("You should give id to Draggable component.")
        const ele = document.getElementById('event_div_'+props.id);
        ele.style.height = ele.parentElement.clientHeight + 'px'
        setElement(ele)
        ele.g_currPos = {x:0, y:0};
        ele.g_currScale = 1;
        ele.g_dragStart = false;
        ele.addEventListener('mousedown', onMouseDown)
        ele.addEventListener('mousemove', onMouseMove)
        ele.addEventListener('mouseup', onMouseUp)
    },[]);
    const onMouseDown = (e)=>{
        const ele = document.elementFromPoint(e.x, e.y);
        if(ele === getElement() && e.buttons === 1 && e.button === 0){
            getElement().g_dragStart = true;
            getElement().g_mouseDownPos = {x:e.x, y: e.y};
        }
    }
    const onMouseMove = (e)=>{
        if( e.buttons === 1 && e.button === 0 && getElement().g_dragStart){
            let newPos = {
                x: (getElement().g_currPos.x + (e.x-getElement().g_mouseDownPos.x)/getElement().g_currScale),
                y: (getElement().g_currPos.y + (e.y-getElement().g_mouseDownPos.y)/getElement().g_currScale)
            }
            newPos.x = Math.max(0, Math.min(newPos.x, getElement().parentElement.parentElement.clientWidth-getElement().parentElement.clientWidth))
            newPos.y = Math.max(0, Math.min(newPos.y, getElement().parentElement.parentElement.clientHeight-getElement().parentElement.clientHeight))
            getElement().parentElement.style.left = newPos.x + 'px';
            getElement().parentElement.style.top =  newPos.y + 'px';
        } 
    }
    const onMouseUp = (e)=>{
        if(getElement().g_dragStart){
            const newPos = {
                x: (getElement().g_currPos.x + (e.x-getElement().g_mouseDownPos.x)/getElement().g_currScale),
                y: (getElement().g_currPos.y + (e.y-getElement().g_mouseDownPos.y)/getElement().g_currScale)
            }
            getElement().g_currPos.x = Math.max(0, Math.min(newPos.x, getElement().parentElement.parentElement.clientWidth-getElement().parentElement.clientWidth))
            getElement().g_currPos.y = Math.max(0, Math.min(newPos.y, getElement().parentElement.parentElement.clientHeight-getElement().parentElement.clientHeight))    
        }
        getElement().g_dragStart = false;
    }
    
    return (
        <div id={props.id}
            style={{position: 'relative', backgroundImage: `url(${props.background})`, display:'inline-block'}}
        >
            {props.children}
            <div id={'event_div_'+props.id} style={{position:'absolute',top:0, zIndex:10000, width:'100%'}}/>
        </div>
    )
        
}
export default DraggableChildren;