module.exports = {
  confirm: 'Email sent, please check your inbox to confirm',
  alreadyRegistered: 'Sorry, the name is already taken.',
  // alreadyConfirmed: 'Your email was already confirmed'
}